#  Welcome Apple,

I'm Dishant and this is my submission for this year's WWDC Swift Student Challenge.

The app simply does one thing that is to teach children digital privacy especially who just started out with tech.Which I see
is ofen neglected in real world space. I want to ensure no one makes a fool out of themselves on the internet.Happened with me
and happens with a lot people too. So I just wanted to create this app and hoping to help if not everyone atleast someone.

As I created my app using Xcode on MacOS and Swift Playground App Project I believe it to run best on iPhone as I don't have
iPad to create and build on.

I prefer my project to be used on iPhone 12 pro max simulator.As it is the best size to display all the UI elements.

                                        INSTRUCTIONS: - 

1.) This is a storybased app so read along the lines.
2.) There are a few acitvities for the chidren to make them think,so please do try them out.
3.) As I intended to make an iOS app and also it works best with iOS simulator(specially iPhone 12 pro max).



Thank you Apple for providing this opportunity.
And I will make this app more practical with more features and realese it on app store for the world to use and learn from it.
